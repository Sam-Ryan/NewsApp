//
//  DetailView.m
//  IOSTV
//
//  Created by Vishal on 4/24/15.
//  Copyright (c) 2015 Vishal. All rights reserved.
//

#import "DetailView.h"
#import "MKInfoPanel.h"
#import "UIImageView+WebCache.h"
#import "ASIFormDataRequest.h"
#import "Reachability.h"
#import "AppDelegate.h"
#import "ListViewDetails.h"
#import "UIDevice+Res.h"


@interface DetailView ()
{
    Reachability *internetReachable;
    NetworkStatus internetStatus;
    GADBannerView *bannerView_;
}
@end

@implementation DetailView

@synthesize tableViewCat,spinner;
@synthesize allTableData;
@synthesize searchResults;
@synthesize isFiltered;
@synthesize CatIdSelect;
@synthesize actBgimg;
@synthesize CatScreenName;

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    
    appDelegate = [[UIApplication sharedApplication] delegate];
    
    internetReachable = [Reachability reachabilityForInternetConnection];
    internetStatus = [internetReachable currentReachabilityStatus];
    
    //spinnerBg
    UIImage *spinnerBg=[UIImage imageNamed:@"spinnerbg.png"];
    actBgimg=[[UIImageView alloc]initWithImage:spinnerBg];
    //actBgimg.frame=CGRectMake(130, 238, 60, 60);
    actBgimg.center = self.view.center;
    actBgimg.layer.masksToBounds = YES;
    actBgimg.layer.cornerRadius = 7.0;
    actBgimg.alpha = 1.0;
    [self.view addSubview:actBgimg];
    actBgimg.hidden = YES;
    
    //AcivityIndicator
    spinner = [[UIActivityIndicatorView alloc] initWithActivityIndicatorStyle:UIActivityIndicatorViewStyleWhiteLarge];
    //spinner.frame = CGRectMake(141, 250,37,37);
    spinner.center=self.view.center;
    [self.view addSubview:spinner];
    spinner.hidden = YES;
    
    
    self.tableViewCat.showsVerticalScrollIndicator = NO;
    if (UI_USER_INTERFACE_IDIOM() == UIUserInterfaceIdiomPad)
    {
        self.tableViewCat.rowHeight = 100.0f;
    }
    else
    {
        self.tableViewCat.rowHeight = 85.0f;
    }
    
    allTableData = [[[NSMutableArray alloc]init] retain];
    self.searchResults = [[[NSMutableArray alloc]init] retain];
    
    // This will remove extra separators from tableview
    tableViewCat.tableFooterView = [[UIView alloc] initWithFrame:CGRectZero];
    tableViewCat.tableHeaderView = [[UIView alloc] initWithFrame:CGRectZero];
}

-(void)startSpinner
{
    actBgimg.hidden = NO;
    spinner.hidden = NO;
    [spinner startAnimating];
    [self.view setUserInteractionEnabled:NO];
}

-(void)stopSpinner
{
    actBgimg.hidden = YES;
    spinner.hidden = YES;
    [spinner stopAnimating];
    [self.view setUserInteractionEnabled:YES];
}

- (void)viewWillAppear:(BOOL)animated {
    
    [super viewWillAppear:animated];
    
    self.navigationController.navigationBarHidden =YES;
    
    bannerView_ = [[GADBannerView alloc] initWithAdSize:kGADAdSizeBanner];
    bannerView_.adUnitID = appDelegate.bannerViewAdUnitID;
    bannerView_.rootViewController = self;
    if (UI_USER_INTERFACE_IDIOM() == UIUserInterfaceIdiomPad)
    {
        bannerView_.frame = CGRectMake(0, self.view.frame.size.height - 50, self.view.frame.size.width, 50);
    }
    else
    {
        if ([UIDevice type] == iPhone4) {
            bannerView_.frame = CGRectMake(0, self.view.frame.size.height - 50, 320, 50);
        }
        else if ([UIDevice type] == iPhone5) {
            bannerView_.frame = CGRectMake(0, self.view.frame.size.height - 50, 320, 50);
        }
        else if ([UIDevice type] == iPhone6) {
            bannerView_.frame = CGRectMake(0, self.view.frame.size.height - 50, 375, 50);
        }
        else if ([UIDevice type] == iPhone6Plus) {
            bannerView_.frame = CGRectMake(0, self.view.frame.size.height - 50, 414, 50);
        }
        
    }
    [self.view addSubview:bannerView_];
    [bannerView_ loadRequest:[GADRequest request]];
    
    
    allTableData = [[NSMutableArray alloc]init];
    self.searchResults = [[NSMutableArray alloc]init];

    
    tableViewCat.backgroundColor = [UIColor clearColor];
    
    [self getLatest];
}

-(void)getLatest
{
    if (internetStatus == 0)
    {
        [self Networkfailure];
    }
    else
    {
        [self startSpinner];

        [allTableData removeAllObjects];
        [searchResults removeAllObjects];
        
        
        NSString *requestUrl = [ NSString stringWithFormat:@"%@api.php?cat_id=%@",appDelegate.domainURL,CatIdSelect];

        NSURL *getLatestUrl = [NSURL URLWithString:requestUrl];
        ASIHTTPRequest *request = [ASIHTTPRequest requestWithURL:getLatestUrl];
        [request setDelegate:self];
        [request startAsynchronous];
    }
}

- (void)requestFinished:(ASIHTTPRequest *)response
{
    // Use when fetching binary data
    NSData *responseData = [response responseData];
    NSDictionary *detailsDict = [NSJSONSerialization JSONObjectWithData:responseData options:NSJSONReadingMutableContainers error:nil];
    
    NSArray *storeArr = [detailsDict valueForKey:@"NewsApp"];
    
    if (storeArr.count > 0) {
        [self stopSpinner];
    }
    
    for (int i=0; i<storeArr.count; i++)
    {
        NSDictionary *storeDict = [storeArr objectAtIndex:i];
        [allTableData addObject:storeDict];
    }

    [tableViewCat reloadData];
}

- (void)requestFailed:(ASIHTTPRequest *)response
{
    [self stopSpinner];
//    NSError *error = [response error];
    //NSString *tagStr = [NSString stringWithFormat:@"-%ld",(long)response.tag];
    NSDictionary* dict = [NSDictionary dictionaryWithObject: response forKey:@"index"];
    
    NSLog(@"requestFailed = %@",dict);
}

-(void)Networkfailure
{
    [self stopSpinner];
    [MKInfoPanel showPanelInView:self.view type:MKInfoPanelTypeError title:@"Network failure!" subtitle:@"Internet connection not available!." hideAfter:2.0];
}

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    // Return the number of sections.
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    if (tableView == self.tableViewCat) {
        // Return the number of rows in the section.
        return self.allTableData.count;
    } else {
        return self.searchResults.count;
    }
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    
    static NSString *CellIdentifier = @"Cell";
    UIImageView * imageView;
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
    if (cell == nil)
    {
        if (UI_USER_INTERFACE_IDIOM() == UIUserInterfaceIdiomPad)
        {
            imageView = [[UIImageView alloc] initWithFrame:CGRectMake(20, 5, 70, 70)];
        }
        else
        {
            imageView = [[UIImageView alloc] initWithFrame:CGRectMake(10, 8, 70, 70)];
        }
        
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CellIdentifier];
    }
    else
    {
        if (UI_USER_INTERFACE_IDIOM() == UIUserInterfaceIdiomPad)
        {
            imageView = [[UIImageView alloc] initWithFrame:CGRectMake(20, 5, 70, 70)];
        }
        else
        {
            imageView = [[UIImageView alloc] initWithFrame:CGRectMake(10, 8, 70, 70)];
        }
        
        cell = nil;
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CellIdentifier];
    }
    
    NSDictionary *tempObj = [allTableData objectAtIndex:indexPath.row];
    if([tempObj valueForKey:@"news_description"] != nil)
    {
        // The key existed...
        CALayer * l = [imageView layer];
        [l setMasksToBounds:YES];
        [l setCornerRadius:10.0];
        
        // You can even add a border
        [l setBorderWidth:2.0];
        [l setBorderColor:[[UIColor lightGrayColor] CGColor]];
        
        NSString *str = [NSString stringWithFormat:@"%@upload/thumbs/%@",appDelegate.domainURL,[tempObj valueForKey:@"news_image"]];

        [imageView setImageWithURL:[NSURL URLWithString:str]];
        
        imageView.layer.backgroundColor=[[UIColor clearColor] CGColor];
        imageView.layer.cornerRadius=35;
        imageView.layer.borderWidth=5.0;
        imageView.layer.masksToBounds = YES;
        [imageView.layer setBorderColor:[UIColor colorWithWhite:1.0f alpha:0.5f].CGColor];
        
        [cell.contentView addSubview:imageView];
        
        UILabel * lblTemp = [[UILabel alloc] init];
        lblTemp.textColor = [UIColor colorWithRed:252/255.0 green:98/255.0 blue:7/255.0 alpha:1.0];
        
        if (UI_USER_INTERFACE_IDIOM() == UIUserInterfaceIdiomPad)
        {
            lblTemp.frame = CGRectMake(125, 15, 620, 25);
            lblTemp.font =  [UIFont fontWithName:@"Arial-BoldMT" size:22];
        }
        else
        {
            lblTemp.frame = CGRectMake(90, 15, 200, 18);
            lblTemp.font =  [UIFont fontWithName:@"Arial-BoldMT" size:17];
        }
        
        lblTemp.text = [tempObj valueForKey:@"category_name"];
        [cell.contentView addSubview:lblTemp];
        
        
        UILabel * lblTemp2 = [[UILabel alloc] init];
        lblTemp2.lineBreakMode = NSLineBreakByWordWrapping;
        lblTemp2.numberOfLines = 5;
        lblTemp2.textColor = [UIColor colorWithRed:81/255.0 green:81/255.0 blue:81/255.0 alpha:1.0];
        
        
        if (UI_USER_INTERFACE_IDIOM() == UIUserInterfaceIdiomPad)
        {
            lblTemp2.frame = CGRectMake(125, 40, 620, 35);
            lblTemp2.font =  [UIFont fontWithName:@"Arial" size:20];
        }
        else
        {
            lblTemp2.frame = CGRectMake(90, 35, 220, 30);
            lblTemp2.font =  [UIFont fontWithName:@"Arial" size:13];
        }
        
        lblTemp2.text = [tempObj valueForKey:@"news_heading"];
        [cell.contentView addSubview:lblTemp2];
    }
    else {
        // No joy...
    
        CALayer * l = [imageView layer];
        [l setMasksToBounds:YES];
        [l setCornerRadius:10.0];
        
        // You can even add a border
        [l setBorderWidth:2.0];
        [l setBorderColor:[[UIColor lightGrayColor] CGColor]];
        
        NSString *str = [NSString stringWithFormat:@"%@upload/category/%@",appDelegate.domainURL,[tempObj valueForKey:@"category_image"]];

        [imageView setImageWithURL:[NSURL URLWithString:str]];
        
        imageView.layer.backgroundColor=[[UIColor clearColor] CGColor];
        imageView.layer.cornerRadius=45;
        imageView.layer.borderWidth=5.0;
        imageView.layer.masksToBounds = YES;
        [imageView.layer setBorderColor:[UIColor colorWithWhite:1.0f alpha:0.5f].CGColor];
        
        [cell.contentView addSubview:imageView];
        
        UILabel * lblTemp = [[UILabel alloc] init];
        lblTemp.numberOfLines = 5;
        
        if (UI_USER_INTERFACE_IDIOM() == UIUserInterfaceIdiomPad)
        {
            lblTemp.frame = CGRectMake(125, 40, 620, 35);
            lblTemp.font =  [UIFont fontWithName:@"Arial-BoldMT" size:25];
        }
        else
        {
            lblTemp.frame = CGRectMake(90, 35, 220, 18);
            lblTemp.font =  [UIFont fontWithName:@"Arial-BoldMT" size:17];
        }
        
        lblTemp.textColor = [UIColor colorWithRed:252/255.0 green:98/255.0 blue:7/255.0 alpha:1.0];
        lblTemp.text = [tempObj valueForKey:@"category_name"];
        [cell.contentView addSubview:lblTemp];
    }
    [cell setBackgroundColor:[UIColor clearColor]];
    
    return cell;
}

//- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
//{
//    return 85.0f;
//}

//- (CGFloat)tableView:(UITableView *)tableView heightForFooterInSection:(NSInteger)section {
//    // This will create a "invisible" footer
//    return 0.01f;
//}
//
//- (UIView *)tableView:(UITableView *)tableView viewForFooterInSection:(NSInteger)section
//{
//    return [UIView new];
//    
//    // If you are not using ARC:
//    // return [[UIView new] autorelease];
//}

- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section {
    // This will create a "invisible" footer
    return 0.01f;
}

- (UIView *)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section
{
    return [UIView new];
    
    // If you are not using ARC:
    // return [[UIView new] autorelease];
}

#pragma mark - Table view delegate

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    NSDictionary *tempObj = [self.allTableData objectAtIndex:indexPath.row];

    if([tempObj valueForKey:@"news_description"] != nil)
    {
        NSString * catSelObj = [[NSString alloc] initWithFormat:@"%@",[tempObj valueForKey:@"cid"]];
        
        ListViewDetails * detailsView;
        
        if (UI_USER_INTERFACE_IDIOM() == UIUserInterfaceIdiomPad)
        {
            detailsView = [[ListViewDetails alloc] initWithNibName:@"ListViewDetails_iPad" bundle:nil];
        }
        else
        {
            if ([UIDevice type] == iPhone4) {
                detailsView = [[ListViewDetails alloc] initWithNibName:@"ListViewDetails_4" bundle:nil];
            }
            else if ([UIDevice type] == iPhone5) {
                detailsView = [[ListViewDetails alloc] initWithNibName:@"ListViewDetails" bundle:nil];
            }
            else if ([UIDevice type] == iPhone6) {
                detailsView = [[ListViewDetails alloc] initWithNibName:@"ListViewDetails_6" bundle:nil];
            }
            else if ([UIDevice type] == iPhone6Plus) {
                detailsView = [[ListViewDetails alloc] initWithNibName:@"ListViewDetails_6Plus" bundle:nil];
            }
        }
        
        //ListViewDetails * detailsView = [[ListViewDetails alloc] initWithNibName:@"ListViewDetails" bundle:nil];
        detailsView.CatIdSelectFor = catSelObj;
        detailsView.SetIndex = (long)indexPath.row;
        if ([CatScreenName isEqualToString:@"Favourites"]) {
            detailsView.CatScreenName = @"Favourites";
        } else if ([CatScreenName isEqualToString:@"Latest"]) {
            detailsView.CatScreenName = @"Latest";
        } else  {
            detailsView.CatScreenName = @"AllNews";
        }
        
        [self.navigationController pushViewController:detailsView animated:YES];
    }
    else {
        
    }
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

-(IBAction)btnBaclClick:(id)sender
{
    [self.navigationController popViewControllerAnimated:YES];
}

/*
 #pragma mark - Navigation
 
 // In a storyboard-based application, you will often want to do a little preparation before navigation
 - (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
 // Get the new view controller using [segue destinationViewController].
 // Pass the selected object to the new view controller.
 }
 */

@end
