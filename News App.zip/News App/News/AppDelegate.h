//
//  AppDelegate.h
//  News
//
//  Created by Vishal on 5/1/15.
//  Copyright (c) 2015 Vishal. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>
{
    NSString * domainURL;
    NSString * SERVER_IMAGE_CATEGORY;
    
    NSString * bannerViewAdUnitID;
    NSString * InterstitialAdUnitID;
}
@property (strong, nonatomic) UIWindow *window;
@property (nonatomic ,retain) IBOutlet NSString * domainURL;
@property (nonatomic ,retain) IBOutlet NSString * SERVER_IMAGE_CATEGORY;
@property (nonatomic ,retain) IBOutlet NSString * bannerViewAdUnitID;
@property (nonatomic ,retain) IBOutlet NSString * InterstitialAdUnitID;

@property (strong, nonatomic) UINavigationController *navigationObj;

@end

