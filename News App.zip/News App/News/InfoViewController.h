
#import <UIKit/UIKit.h>
#import "AppDelegate.h"
#import "GADBannerView.h"

@interface InfoViewController : UIViewController
{
    AppDelegate * appDelegate;
    
    UIImageView * logImgeView;
    UILabel * appNameLbl;
    UILabel * emailLbl;
    UILabel * urlLbl;
    UITextView * detailsTextView;
    
}

@property (nonatomic,retain) UIActivityIndicatorView *spinner;
@property (nonatomic,retain) UIImageView *actBgimg;
@property (strong, nonatomic) NSMutableArray* allArrayData;

@property (retain, nonatomic) IBOutlet UIImageView * logImgeView;
@property (retain, nonatomic) IBOutlet UILabel * appNameLbl;
@property (retain, nonatomic) IBOutlet UILabel * emailLbl;
@property (retain, nonatomic) IBOutlet UILabel * urlLbl;
@property (retain, nonatomic) IBOutlet UITextView * detailsTextView;

-(IBAction)btnBackClick:(id)sender;
@end
