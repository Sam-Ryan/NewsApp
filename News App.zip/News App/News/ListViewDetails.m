//
//  ListViewDetails.m
//  IOSTV
//
//  Created by Vishal on 4/24/15.
//  Copyright (c) 2015 Vishal. All rights reserved.
//

#import "ListViewDetails.h"
#import "MKInfoPanel.h"
#import "FMDatabase.h"
#import "FMResultSet.h"
#import "UIImageView+WebCache.h"
#import "ASIFormDataRequest.h"
#import "Reachability.h"
#import "AppDelegate.h"
#import "UIDevice+Res.h"
#import "ARSpeechActivity.h"
#import <Social/Social.h>


@interface ListViewDetails ()
{
    Reachability *internetReachable;
    NetworkStatus internetStatus;
    GADBannerView *bannerView_;
    GADInterstitial *interstitial_;
}
@property (nonatomic, assign) int isPlay2;


@end

@implementation ListViewDetails

@synthesize pageControl,pageInt,index;
@synthesize actBgimg,spinner;
@synthesize imageArray;
@synthesize CatIdSelectFor;
@synthesize channelUrlString,CatScreenName;
@synthesize allDataArray;
@synthesize SetIndex;

//static int sCurrPlayIdx;

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    
    //NSLog(@"SetIndex = %ld",(long)SetIndex);
    
    //NSLog(@"CatIdSelectFor= %@",CatIdSelectFor);
    //NSLog(@"CatScreenName= %@",CatScreenName);
    appDelegate = [[UIApplication sharedApplication] delegate];
    
    internetReachable = [Reachability reachabilityForInternetConnection];
    internetStatus = [internetReachable currentReachabilityStatus];
    
    
    //spinnerBg
    UIImage *spinnerBg=[UIImage imageNamed:@"spinnerbg.png"];
    actBgimg=[[UIImageView alloc]initWithImage:spinnerBg];
    //actBgimg.frame=CGRectMake(130, 238, 60, 60);
    actBgimg.center = self.view.center;
    actBgimg.layer.masksToBounds = YES;
    actBgimg.layer.cornerRadius = 7.0;
    actBgimg.alpha = 1.0;
    [self.view addSubview:actBgimg];
    actBgimg.hidden = YES;
    
    //AcivityIndicator
    spinner = [[UIActivityIndicatorView alloc] initWithActivityIndicatorStyle:UIActivityIndicatorViewStyleWhiteLarge];
    //spinner.frame = CGRectMake(141, 250,37,37);
    spinner.center=self.view.center;
    [self.view addSubview:spinner];
    spinner.hidden = YES;
    
    
    
    imageArray = [[[NSMutableArray alloc]init] retain];
    
    NSString *SelectScreenValue = [[NSUserDefaults standardUserDefaults] stringForKey:@"SelectScreen"];

    if ([SelectScreenValue isEqualToString:@"Favourites"]) {
        [self SelectAllData];
        if ([UIDevice type] == iPhone4) {
            ShareButton.hidden = YES;
            btnFav.frame = CGRectMake(270, 21, 40, 40);
        }
        else if ([UIDevice type] == iPhone5) {
            ShareButton.hidden = YES;
            btnFav.frame = CGRectMake(270, 21, 40, 40);
        }
        else if ([UIDevice type] == iPhone6) {
            ShareButton.hidden = YES;
            btnFav.frame = CGRectMake(321, 21, 40, 40);
        }
        else if ([UIDevice type] == iPhone6Plus) {
            ShareButton.hidden = YES;
            btnFav.frame = CGRectMake(360, 21, 40, 40);
        }
        
    } else if ([SelectScreenValue isEqualToString:@"Latest"]){
        [self getLatest];
        
    } else if ([SelectScreenValue isEqualToString:@"AllNews"]){
        [self getLatest];
        
    } else {
        [self getLatest];
    }
    
    
    bannerView_ = [[GADBannerView alloc] initWithAdSize:kGADAdSizeBanner];
    bannerView_.adUnitID = appDelegate.bannerViewAdUnitID;
    bannerView_.rootViewController = self;
    if (UI_USER_INTERFACE_IDIOM() == UIUserInterfaceIdiomPad)
    {
        bannerView_.frame = CGRectMake(0, self.view.frame.size.height - 50, self.view.frame.size.width, 50);
    }
    else
    {
        if ([UIDevice type] == iPhone4) {
            bannerView_.frame = CGRectMake(0, self.view.frame.size.height - 50, 320, 50);
        }
        else if ([UIDevice type] == iPhone5) {
            bannerView_.frame = CGRectMake(0, self.view.frame.size.height - 50, 320, 50);
        }
        else if ([UIDevice type] == iPhone6) {
            bannerView_.frame = CGRectMake(0, self.view.frame.size.height - 50, 375, 50);
        }
        else if ([UIDevice type] == iPhone6Plus) {
            bannerView_.frame = CGRectMake(0, self.view.frame.size.height - 50, 414, 50);
        }
        
    }
    [self.view addSubview:bannerView_];
    [bannerView_ loadRequest:[GADRequest request]];
    
    [self performSelector:@selector(createAndLoadInterstitial) withObject:nil afterDelay:1.5];
}

- (void)createAndLoadInterstitial {
    // Do any additional setup after loading the view, typically from a nib.
    interstitial_ = [[GADInterstitial alloc] init];
    interstitial_.adUnitID = appDelegate.InterstitialAdUnitID;
    interstitial_.delegate = self;
    [interstitial_ loadRequest:[GADRequest request]];
}
#pragma mark GADInterstitialDelegate implementation

//- (void)interstitialDidReceiveAd:(DFPInterstitial *)ad
//{
//    [self stopSpinner];
//    [interstitial_ presentFromRootViewController:self];
//}

- (void)interstitialDidReceiveAd:(GADInterstitial *)interstitial{
    [self stopSpinner];
    NSLog(@"interstitialDidReceiveAd");
    [interstitial_ presentFromRootViewController:self];
}

- (void)interstitial:(GADInterstitial *)interstitial
didFailToReceiveAdWithError:(GADRequestError *)error {
    NSLog(@"interstitialDidFailToReceiveAdWithError: %@", [error localizedDescription]);
}

- (void)interstitialDidDismissScreen:(GADInterstitial *)interstitial {
    //NSLog(@"interstitialDidDismissScreen");
    [self stopSpinner];
    
}

-(void)startSpinner
{
    actBgimg.hidden = NO;
    spinner.hidden = NO;
    [spinner startAnimating];
    [self.view setUserInteractionEnabled:NO];
}

-(void)stopSpinner
{
    actBgimg.hidden = YES;
    spinner.hidden = YES;
    [spinner stopAnimating];
    [self.view setUserInteractionEnabled:YES];
}

- (void)viewWillAppear:(BOOL)animated {
    
    [super viewWillAppear:animated];
    self.navigationController.navigationBarHidden =YES;
    
    //[ShareButton addTarget:self action:@selector(showActivities:) forControlEvents:UIControlEventTouchUpInside];
    
    [ShareButton addTarget:self action:@selector(showActivities2:) forControlEvents:UIControlEventTouchUpInside];
}

-(void)getLatest
{
    if (internetStatus == 0)
    {
        [self Networkfailure];
    }
    else
    {
        [self startSpinner];
        
        NSString *requestUrl;
        if ([CatScreenName isEqualToString:@"AllNews"]) {
            requestUrl = [ NSString stringWithFormat:@"%@api.php?cat_id=%@",appDelegate.domainURL,CatIdSelectFor];
        }
        else
        {
           requestUrl = [ NSString stringWithFormat:@"%@api.php?latest_news=10",appDelegate.domainURL];
        }
        
        NSURL *getLatestUrl = [NSURL URLWithString:requestUrl];
        ASIHTTPRequest *request = [ASIHTTPRequest requestWithURL:getLatestUrl];
        [request setDelegate:self];
        [request startAsynchronous];
    }
}

- (void)requestFinished:(ASIHTTPRequest *)response
{
    // Use when fetching binary data
    NSData *responseData = [response responseData];
    NSDictionary *detailsDict = [NSJSONSerialization JSONObjectWithData:responseData options:NSJSONReadingMutableContainers error:nil];

    NSArray *storeArr = [detailsDict valueForKey:@"NewsApp"];
    
    for (int i=0; i<storeArr.count; i++)
    {
        NSDictionary *storeDict = [storeArr objectAtIndex:i];
        [imageArray addObject:storeDict];
    }
    if (storeArr.count > 0) {
        
        [self performSelector:@selector(getAllImages) withObject:nil afterDelay:1.0];
    }
    
}

- (void)requestFailed:(ASIHTTPRequest *)response
{
    [self stopSpinner];
    //NSError *error = [response error];
    //NSString *tagStr = [NSString stringWithFormat:@"-%ld",(long)response.tag];
    NSDictionary* dict = [NSDictionary dictionaryWithObject: response forKey:@"index"];
    
    NSLog(@"requestFailed = %@",dict);
}

-(void)Networkfailure
{
    [self stopSpinner];
    [MKInfoPanel showPanelInView:self.view type:MKInfoPanelTypeError title:@"Network failure!" subtitle:@"Internet connection not available!." hideAfter:2.0];
}

-(void)getAllImages
{
    [scrolViewobj.subviews makeObjectsPerformSelector:@selector(removeFromSuperview)];
    
    
    //[imageArray retain];
    if (self.imageArray.count > 0) {
        [self stopSpinner];
    }
    pageControl.numberOfPages = self.imageArray.count;
    pageControl.currentPage = self.index;
    for (int i=0; i< self.imageArray.count; i++)
    {
        NSDictionary *dict = [self.imageArray objectAtIndex:i];
        
        UIView *viewObj;
        
        if (UI_USER_INTERFACE_IDIOM() == UIUserInterfaceIdiomPad)
        {
            viewObj = [[UIView alloc]initWithFrame:CGRectMake((i*768)+21, 20, 728, 880)];
        }
        else
        {
            if ([UIDevice type] == iPhone4) {
                viewObj = [[UIView alloc]initWithFrame:CGRectMake((i*320)+10, 17, 300, 330)];
            }
            else if ([UIDevice type] == iPhone5) {
                viewObj = [[UIView alloc]initWithFrame:CGRectMake((i*320)+10, 17, 300, 430)];
            }
            else if ([UIDevice type] == iPhone6) {
                viewObj = [[UIView alloc]initWithFrame:CGRectMake((i*375)+10, 17, 355, 500)];
            }
            else if ([UIDevice type] == iPhone6Plus) {
                viewObj = [[UIView alloc]initWithFrame:CGRectMake((i*414)+10, 17, 395, 550)];
            }
        }

        
        viewObj.backgroundColor = [UIColor colorWithRed:241/255.0f green:241/255.0f blue:241/255.0f alpha:0.5];
        viewObj.layer.cornerRadius = 7.0f;
        [viewObj.layer setBorderColor: [[UIColor lightGrayColor] CGColor]];
        [viewObj.layer setBorderWidth: 2.0];
        
        //************* Add imageView in view *****************
        UIImageView * imageObj;
        
        
        if (UI_USER_INTERFACE_IDIOM() == UIUserInterfaceIdiomPad)
        {
            imageObj =[[UIImageView alloc] initWithFrame:CGRectMake(2, 2, 724, 450)];
        }
        else
        {
            if ([UIDevice type] == iPhone4) {
                imageObj =[[UIImageView alloc] initWithFrame:CGRectMake(2, 2, 298, 200)];
            }
            else if ([UIDevice type] == iPhone5) {
                imageObj =[[UIImageView alloc] initWithFrame:CGRectMake(2, 2, 298, 200)];
            }
            else if ([UIDevice type] == iPhone6) {
                imageObj =[[UIImageView alloc] initWithFrame:CGRectMake(2, 2, 351, 200)];
            }
            else if ([UIDevice type] == iPhone6Plus) {
                imageObj =[[UIImageView alloc] initWithFrame:CGRectMake(2, 2, 298, 200)];
            }
        }
        
        
        
        //UIImageView * imageObj =[[UIImageView alloc] initWithFrame:CGRectMake(2, 2, 298, 200)];
        imageObj.layer.masksToBounds = YES;
        imageObj.contentMode = UIViewContentModeScaleToFill;
        imageObj.tag = i;
        
        NSString *str = [NSString stringWithFormat:@"%@upload/%@",appDelegate.domainURL,[dict valueForKey:@"news_image"]];
        
//        UIActivityIndicatorView *activityIndicator = [[UIActivityIndicatorView alloc] initWithActivityIndicatorStyle:UIActivityIndicatorViewStyleWhiteLarge];
//        activityIndicator.center = imageObj.center;
//        activityIndicator.hidesWhenStopped = YES;
//        
//        [imageObj setImageWithURL:[NSURL URLWithString:str] placeholderImage:[UIImage imageNamed:@"placeholder.png"] success:^(UIImage *image, BOOL cached) {
//            [activityIndicator  removeFromSuperview];
//        } failure:^(NSError *error) {
//            [activityIndicator  removeFromSuperview];
//        }];
//        
//        [imageObj addSubview:activityIndicator];
//        [activityIndicator startAnimating];
        
        [imageObj setImageWithURL:[NSURL URLWithString:str]];
        imageObj.layer.cornerRadius = 5.0;
        [imageObj.layer setBorderColor: [[UIColor clearColor] CGColor]];
        [viewObj addSubview:imageObj];
        
        //************* Add Lable in view *****************
        UILabel * lblTemp;
        
        if (UI_USER_INTERFACE_IDIOM() == UIUserInterfaceIdiomPad)
        {
            lblTemp = [[UILabel alloc] initWithFrame:CGRectMake(20, 463, 630, 35)];
            lblTemp.font =  [UIFont fontWithName:@"Arial-BoldMT" size:30];
        }
        else
        {
            if ([UIDevice type] == iPhone4) {
                lblTemp = [[UILabel alloc] initWithFrame:CGRectMake(15, 215, 220, 20)];
            }
            else if ([UIDevice type] == iPhone5) {
                lblTemp = [[UILabel alloc] initWithFrame:CGRectMake(15, 215, 220, 20)];
            }
            else if ([UIDevice type] == iPhone6) {
                lblTemp = [[UILabel alloc] initWithFrame:CGRectMake(15, 215, 220, 20)];
            }
            else if ([UIDevice type] == iPhone6Plus) {
                lblTemp = [[UILabel alloc] initWithFrame:CGRectMake(15, 215, 220, 20)];
            }
            lblTemp.font =  [UIFont fontWithName:@"Arial-BoldMT" size:17];
        }
        
        
        //UILabel * lblTemp = [[UILabel alloc] initWithFrame:CGRectMake(15, 215, 260, 20)];
        //lblTemp.backgroundColor = [UIColor grayColor];
        lblTemp.textColor = [UIColor colorWithRed:252/255.0 green:98/255.0 blue:7/255.0 alpha:1.0];
        lblTemp.text = [dict valueForKey:@"category_name"];
        [viewObj addSubview:lblTemp];
        
        //************* Add Calender imageView in view *****************
        
        UIImageView * imageObjcal;
        
        
        if (UI_USER_INTERFACE_IDIOM() == UIUserInterfaceIdiomPad)
        {
            imageObjcal =[[UIImageView alloc] initWithFrame:CGRectMake(520, 465, 30, 30)];
        }
        else
        {
            if ([UIDevice type] == iPhone4) {
                imageObjcal =[[UIImageView alloc] initWithFrame:CGRectMake(193, 214, 20, 20)];
            }
            else if ([UIDevice type] == iPhone5) {
                imageObjcal =[[UIImageView alloc] initWithFrame:CGRectMake(193, 214, 20, 20)];
            }
            else if ([UIDevice type] == iPhone6) {
                imageObjcal =[[UIImageView alloc] initWithFrame:CGRectMake(240, 214, 20, 20)];
            }
            else if ([UIDevice type] == iPhone6Plus) {
                imageObjcal =[[UIImageView alloc] initWithFrame:CGRectMake(240, 214, 20, 20)];
            }
        }
        
        
        
        //UIImageView * imageObjcal =[[UIImageView alloc] initWithFrame:CGRectMake(193, 214, 20, 20)];
        imageObjcal.layer.masksToBounds = YES;
        imageObjcal.contentMode = UIViewContentModeScaleToFill;
        [imageObjcal setImage:[UIImage imageNamed:@"calendar_icon"]];
        [viewObj addSubview:imageObjcal];
        
        //************* Add Date Lable in view *****************
        UILabel * lblDate;
        
        if (UI_USER_INTERFACE_IDIOM() == UIUserInterfaceIdiomPad)
        {
            lblDate = [[UILabel alloc] initWithFrame:CGRectMake(560, 467, 150, 30)];
            lblDate.font =  [UIFont fontWithName:@"Arial" size:22];
        }
        else
        {
            if ([UIDevice type] == iPhone4) {
                lblDate = [[UILabel alloc] initWithFrame:CGRectMake(220, 218, 100, 15)];
            }
            else if ([UIDevice type] == iPhone5) {
                lblDate = [[UILabel alloc] initWithFrame:CGRectMake(220, 218, 100, 15)];
            }
            else if ([UIDevice type] == iPhone6) {
                lblDate = [[UILabel alloc] initWithFrame:CGRectMake(270, 218, 100, 15)];
            }
            else if ([UIDevice type] == iPhone6Plus) {
                lblDate = [[UILabel alloc] initWithFrame:CGRectMake(270, 218, 100, 15)];
            }
            lblDate.font =  [UIFont fontWithName:@"Arial" size:13];
        }
        
        
        //UILabel * lblDate = [[UILabel alloc] initWithFrame:CGRectMake(220, 218, 100, 15)];
        //lblTemp.backgroundColor = [UIColor grayColor];
        
        lblDate.textColor = [UIColor grayColor];
        lblDate.text = [dict valueForKey:@"news_date"];
        [viewObj addSubview:lblDate];
        
        //************* Add TextView *****************
        UITextView *newTextView;

        if (UI_USER_INTERFACE_IDIOM() == UIUserInterfaceIdiomPad)
        {
            newTextView = [[UITextView alloc] initWithFrame:CGRectMake(15, 500, 700, 377)];
            newTextView.font =  [UIFont fontWithName:@"Arial" size:25];
        }
        else
        {
            if ([UIDevice type] == iPhone4) {
                newTextView = [[UITextView alloc] initWithFrame:CGRectMake(10, 240, 280, 80)];
            }
            else if ([UIDevice type] == iPhone5) {
                newTextView = [[UITextView alloc] initWithFrame:CGRectMake(10, 240, 280, 170)];
            }
            else if ([UIDevice type] == iPhone6) {
                newTextView = [[UITextView alloc] initWithFrame:CGRectMake(10, 240, 335, 250)];
            }
            else if ([UIDevice type] == iPhone6Plus) {
                newTextView = [[UITextView alloc] initWithFrame:CGRectMake(10, 240, 335, 250)];
            }
            newTextView.font =  [UIFont fontWithName:@"Arial" size:14];
        }

        
        //UITextView *newTextView = [[UITextView alloc] initWithFrame:CGRectMake(10, 240, 280, 230)];
        
        newTextView.scrollEnabled = YES;
        newTextView.backgroundColor = [UIColor clearColor];
        newTextView.textColor = [UIColor colorWithRed:75/255.0f green:75/255.0f blue:75/255.0f alpha:1.0];
        newTextView.text = [dict valueForKey:@"news_description"];
        newTextView.userInteractionEnabled = YES;
        newTextView.editable = NO;
        [viewObj addSubview:newTextView];
        
        [scrolViewobj addSubview:viewObj];
        scrolViewobj.delegate=self;
        if (UI_USER_INTERFACE_IDIOM() == UIUserInterfaceIdiomPad)
        {
            scrolViewobj.contentSize=CGSizeMake((768*imageArray.count),190);
        }
        else
        {
            if ([UIDevice type] == iPhone4) {
                scrolViewobj.contentSize=CGSizeMake((320*imageArray.count),190);
            }
            else if ([UIDevice type] == iPhone5) {
                scrolViewobj.contentSize=CGSizeMake((320*imageArray.count),190);
            }
            else if ([UIDevice type] == iPhone6) {
                scrolViewobj.contentSize=CGSizeMake((375*imageArray.count),190);
            }
            else if ([UIDevice type] == iPhone6Plus) {
                scrolViewobj.contentSize=CGSizeMake((414*imageArray.count),190);
            }
        }
    }
    if ((long)SetIndex) {
        
        if (UI_USER_INTERFACE_IDIOM() == UIUserInterfaceIdiomPad)
        {
            [scrolViewobj setContentOffset:CGPointMake(768*(long)SetIndex, 0) animated:NO];
        }
        else
        {
            if ([UIDevice type] == iPhone4) {
                [scrolViewobj setContentOffset:CGPointMake(320*(long)SetIndex, 0) animated:NO];
            }
            else if ([UIDevice type] == iPhone5) {
                [scrolViewobj setContentOffset:CGPointMake(320*(long)SetIndex, 0) animated:NO];
            }
            else if ([UIDevice type] == iPhone6) {
                [scrolViewobj setContentOffset:CGPointMake(375*(long)SetIndex, 0) animated:NO];
            }
            else if ([UIDevice type] == iPhone6Plus) {
                [scrolViewobj setContentOffset:CGPointMake(414*(long)SetIndex, 0) animated:NO];
            }
        }
        
        

    } else {
        
        if (UI_USER_INTERFACE_IDIOM() == UIUserInterfaceIdiomPad)
        {
            [scrolViewobj setContentOffset:CGPointMake(768*self.index, 0) animated:NO];
        }
        else
        {
            if ([UIDevice type] == iPhone4) {
                [scrolViewobj setContentOffset:CGPointMake(320*self.index, 0) animated:NO];
            }
            else if ([UIDevice type] == iPhone5) {
                [scrolViewobj setContentOffset:CGPointMake(320*self.index, 0) animated:NO];
            }
            else if ([UIDevice type] == iPhone6) {
                [scrolViewobj setContentOffset:CGPointMake(375*self.index, 0) animated:NO];
            }
            else if ([UIDevice type] == iPhone6Plus) {
                [scrolViewobj setContentOffset:CGPointMake(414*self.index, 0) animated:NO];
            }
        }
        
        
    }
    [self scrollViewDidScroll:scrolViewobj];
}

- (void)scrollViewDidScroll:(UIScrollView *)scrollView
{
    CGFloat pageWidth = scrolViewobj.frame.size.width;
    int page = floor((scrolViewobj.contentOffset.x - pageWidth / 2 ) / pageWidth) + 1; //this provide you the page number
    self.pageInt = page;

    pageControl.currentPage = page;// this displays the white dot as current page

    [btnFav setImage:[UIImage imageNamed:@"favourite_icon"] forState:UIControlStateNormal];
    btnFav.tag = 0;
    
    FMDatabase *database = [FMDatabase databaseWithPath:[self databasePath]];
    [database open];
    
    //NSLog(@"[self.imageArray objectAtIndex:page] = %@",[self.imageArray objectAtIndex:page]);
    
    if ([CatScreenName isEqual:@"Favourites"]) {
        
        NSDictionary *dict = [self.imageArray objectAtIndex:page];
        
        NSString *query = [NSString stringWithFormat:@"SELECT nid from Favorite where nid ='%@'",[dict valueForKey:@"nid"]];
        FMResultSet *resultStr = [database executeQuery:query];
        if ([resultStr next]) {
             [btnFav setImage:[UIImage imageNamed:@"favourite_active"] forState:UIControlStateNormal];
            btnFav.tag = 1;
        }
    }
    
    else if ([CatScreenName isEqualToString:@"Latest"]) {
        NSDictionary *dict = [self.imageArray objectAtIndex:page];
        
        NSString *query = [NSString stringWithFormat:@"SELECT nid from Favorite where nid ='%@'",[dict valueForKey:@"nid"]];
        FMResultSet *resultStr = [database executeQuery:query];
        if ([resultStr next]) {
            [btnFav setImage:[UIImage imageNamed:@"favourite_active"] forState:UIControlStateNormal];
            btnFav.tag = 1;
        }
    }
    else{
        NSDictionary *dict = [self.imageArray objectAtIndex:page];
        
        NSString *query = [NSString stringWithFormat:@"SELECT nid from Favorite where nid='%@'",[dict valueForKey:@"nid"]];
        //NSLog(@"query = %@",query);
        FMResultSet *resultStr = [database executeQuery:query];
        if ([resultStr next]) {
            //NSLog(@"YES");
            [btnFav setImage:[UIImage imageNamed:@"favourite_active"] forState:UIControlStateNormal];
            btnFav.tag = 1;
        }
    }
}

-(NSString *) databasePath
{
    NSArray *paths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
    NSString *documentsDir = [paths objectAtIndex:0];
    NSString *dbPath = [documentsDir stringByAppendingPathComponent:@"News.sqlite"];
    //BOOL success = [fileManager fileExistsAtPath:dbPath];
    return dbPath;
}

-(void) SelectAllData
{
    //[self.imageArray removeAllObjects];
 
    FMDatabase *database = [FMDatabase databaseWithPath:[self databasePath]];
    [database open];
    NSString *queryStr = [NSString stringWithFormat:@"SELECT * from Favorite"];
    FMResultSet *resultStr = [database executeQuery:queryStr];
    
    
    while ([resultStr next]) {
        
 
        
        NSMutableDictionary *xyz=[[NSMutableDictionary alloc] init];
        
        // Let's go the other way...
        
        // NSData from the Base64 encoded str
        NSData * nsdataFromBase64String1 = [[NSData alloc] initWithBase64EncodedString:[resultStr stringForColumn:@"categoryname"] options:0];
        NSData * nsdataFromBase64String2 = [[NSData alloc] initWithBase64EncodedString:[resultStr stringForColumn:@"newsheading"] options:0];
        NSData * nsdataFromBase64String3 = [[NSData alloc] initWithBase64EncodedString:[resultStr stringForColumn:@"newsdesc"] options:0];
        // Decoded NSString from the NSData

        NSString *categoryname_base64Decoded = [[NSString alloc] initWithData:nsdataFromBase64String1 encoding:NSUTF8StringEncoding];
        NSString *newsheading_base64Decoded = [[NSString alloc] initWithData:nsdataFromBase64String2 encoding:NSUTF8StringEncoding];
        NSString *newsdesc_base64Decoded = [[NSString alloc] initWithData:nsdataFromBase64String3 encoding:NSUTF8StringEncoding];
        //NSLog(@"Decoded: %@", newsdesc_base64Decoded);

        [xyz setValue:[resultStr stringForColumn:@"nid"] forKey:@"nid"];
        [xyz setValue:[resultStr stringForColumn:@"catid"] forKey:@"id"];
        [xyz setValue:[resultStr stringForColumn:@"cid"] forKey:@"cid"];
        [xyz setValue:categoryname_base64Decoded forKey:@"category_name"];
        [xyz setValue:newsheading_base64Decoded forKey:@"news_heading"];
        [xyz setValue:[resultStr stringForColumn:@"newsimage"] forKey:@"news_image"];
        [xyz setValue:newsdesc_base64Decoded forKey:@"news_description"];
        [xyz setValue:[resultStr stringForColumn:@"newsdate"] forKey:@"news_date"];
        
        [self.imageArray addObject:xyz];
    }
   
    if (self.imageArray > 0) {
        
        [self performSelector:@selector(getAllImages) withObject:nil afterDelay:1.0];
    }
    
}

-(IBAction)btnFavClick:(id)sender
{
    UIButton *btn = (UIButton *)sender;

    FMDatabase *database = [FMDatabase databaseWithPath:[self databasePath]];
    
    [database open];
    
    if (btn.tag == 0) {
        [btn setImage:[UIImage imageNamed:@"favourite_active"] forState:UIControlStateNormal];
        btn.tag = 1;
 
        NSDictionary *dict = [self.imageArray objectAtIndex:self.pageInt];
        
        
        //[dict valueForKey:@"category_name"]
        //[dict valueForKey:@"news_heading"]
        //[dict valueForKey:@"news_description"],
        
        
        
        //refrence link ==>> http://iosdevelopertips.com/core-services/encode-decode-using-base64.html
         
        // Create NSData object
        NSData *nsdata1 = [[dict valueForKey:@"news_description"] dataUsingEncoding:NSUTF8StringEncoding];
        NSData *nsdata2 = [[dict valueForKey:@"category_name"] dataUsingEncoding:NSUTF8StringEncoding];
        NSData * nsdata3 = [[dict valueForKey:@"news_heading"] dataUsingEncoding:NSUTF8StringEncoding];
       
        NSString *news_description_base64Encoded = [nsdata1 base64EncodedStringWithOptions:0];
        NSString * category_name_base64Encoded = [nsdata2 base64EncodedStringWithOptions:0];
        NSString * news_heading_base64Encoded = [nsdata3 base64EncodedStringWithOptions:0];
        
        //NSLog(@"Encoded: %@", news_description_base64Encoded);
        
        
        
        NSString *imageURL = [NSString stringWithFormat:@"%@",[dict valueForKey:@"news_image"]];
        NSString *query = [NSString stringWithFormat:@"insert into Favorite (nid,catid,cid,categoryname,newsheading,newsimage,newsdesc,newsdate) VALUES ('%@','%@','%@','%@','%@','%@','%@','%@')",[dict valueForKey:@"nid"],[dict valueForKey:@"cat_id"],[dict valueForKey:@"cid"],category_name_base64Encoded,news_heading_base64Encoded,imageURL,news_description_base64Encoded,[dict valueForKey:@"news_date"]];
 
        [database executeUpdate:query];
        [database close];
        
    }
    else
    {
        
        [btn setImage:[UIImage imageNamed:@"favourite_icon"] forState:UIControlStateNormal];
        btn.tag = 0;
        
        NSDictionary *dict = [self.imageArray objectAtIndex:self.pageInt];

        NSString *query = [NSString stringWithFormat:@"SELECT nid from Favorite where nid='%@'",[dict valueForKey:@"nid"]];
        
        FMResultSet *resultStr = [database executeQuery:query];
        if ([resultStr next]) {
            NSString *Delquery = [NSString stringWithFormat:@"DELETE from Favorite where nid='%@'",[dict valueForKey:@"nid"]];
            [database executeUpdate:Delquery];
        }
        [database close];
    }
}

-(IBAction)showActivities:(id)sender
{
    
    //[ShareButton addTarget:self action:@selector(showActivities2:) forControlEvents:UIControlEventTouchUpInside];
    //[self startSpinner];
    
}

- (void)showActivities2:(UIButton *)button {
    
    //[self startSpinner];
    
    NSDictionary *dict = [self.imageArray objectAtIndex:self.pageInt];
    
    NSString * imageURL = [NSString stringWithFormat:@"%@upload/%@",appDelegate.domainURL,[dict valueForKey:@"news_image"]];
    
    NSString * news_heading = [NSString stringWithFormat:@"%@\n\n",[dict valueForKey:@"news_heading"]];
    NSString * news_description = [NSString stringWithFormat:@"%@",[dict valueForKey:@"news_description"]];
    
    NSString *text = news_heading;
    
    NSURL* url = [NSURL URLWithString:imageURL];
    NSData* data = [NSData dataWithContentsOfURL:url];
    UIImage* image = [UIImage imageWithData:data];
    
    NSString *desc = news_description;
    
    NSArray * activityItems = @[image, text , desc];
    
    if (UI_USER_INTERFACE_IDIOM() == UIUserInterfaceIdiomPad)
    {
        ARSpeechActivity *speechActivity = [[ARSpeechActivity alloc] init];
        
        UIActivityViewController *activityVC = [[UIActivityViewController alloc] initWithActivityItems:activityItems applicationActivities:@[speechActivity]];
        activityVC.popoverPresentationController.sourceView = button;
        activityVC.popoverPresentationController.sourceRect = button.bounds;
        [self presentViewController:activityVC animated:YES completion:nil];
        //[self stopSpinner];
    }
    else
    {
        ARSpeechActivity *speechActivity = [[ARSpeechActivity alloc] init];
        
        UIActivityViewController *activityVC = [[UIActivityViewController alloc] initWithActivityItems:activityItems applicationActivities:@[speechActivity]];
        [self presentViewController:activityVC animated:YES completion:nil];
        //[self stopSpinner];
    }
}

-(IBAction)btnBaclClick:(id)sender
{
    [self.navigationController popViewControllerAnimated:YES];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
 #pragma mark - Navigation
 
 // In a storyboard-based application, you will often want to do a little preparation before navigation
 - (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
 // Get the new view controller using [segue destinationViewController].
 // Pass the selected object to the new view controller.
 }
 */

@end
