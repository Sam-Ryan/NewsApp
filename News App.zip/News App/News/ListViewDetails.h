//
//  ListViewDetails.h
//  IOSTV
//
//  Created by Vishal on 4/24/15.
//  Copyright (c) 2015 Vishal. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "GADBannerView.h"
#import "GADInterstitial.h"
@class AppDelegate;


@interface ListViewDetails : UIViewController <UIScrollViewDelegate,GADInterstitialDelegate>
{
    AppDelegate * appDelegate;
    NSString * CatIdSelectFor;
    NSString * CatScreenName;
    NSInteger pageInt;
    NSInteger index;
    
    IBOutlet UIScrollView *scrolViewobj;
    NSString * channelUrlString;
    IBOutlet UIButton *btnFav;
    NSMutableArray * allDataArray;
    NSInteger SetIndex;
    IBOutlet UIButton * ShareButton;
    
}

@property (nonatomic,retain) UIActivityIndicatorView *spinner;
@property (nonatomic,retain) UIImageView *actBgimg;
@property (nonatomic,retain) NSMutableArray *imageArray;

@property (nonatomic,retain) NSMutableArray *allDataArray;

@property (nonatomic, assign) IBOutlet NSString *CatIdSelectFor;
@property (nonatomic,retain) UIPageControl *pageControl;
@property (nonatomic,assign) NSInteger pageInt;
@property (nonatomic,assign) NSInteger index;
@property (nonatomic,assign) NSString * channelUrlString;
@property (nonatomic,assign) NSString * CatScreenName;
@property (nonatomic,assign) NSInteger SetIndex;
@end
