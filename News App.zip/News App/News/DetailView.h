//
//  DetailView.h
//  IOSTV
//
//  Created by Vishal on 4/24/15.
//  Copyright (c) 2015 Vishal. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "GADBannerView.h"
@class AppDelegate;


@interface DetailView : UIViewController
{
    AppDelegate * appDelegate;
    NSString * CatIdSelect;
}
@property (nonatomic,retain) IBOutlet UITableView * tableViewCat;
@property (nonatomic,retain) UIActivityIndicatorView *spinner;
@property (nonatomic,retain) UIImageView *actBgimg;
@property (nonatomic, assign) IBOutlet NSString *CatIdSelect;

@property (strong, nonatomic) NSMutableArray* allTableData;
@property (nonatomic, strong) NSMutableArray *searchResults;
@property (nonatomic, assign) bool isFiltered;

@property (nonatomic,assign) NSString * CatScreenName;

@end
