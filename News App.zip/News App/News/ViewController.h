//
//  ViewController.h
//  News
//
//  Created by Vishal on 5/1/15.
//  Copyright (c) 2015 Vishal. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"
#import "InfoViewController.h"
#import "GADBannerView.h"

@interface ViewController : UIViewController
{
    AppDelegate * appDelegate;
    InfoViewController *infoViewObj;
    
    IBOutlet UIButton *btnLatest;
    IBOutlet UIButton *btnAllNews;
    IBOutlet UIButton *btnMyFavorites;
    
    IBOutlet UIImageView *selImageObj;
    
    NSMutableArray *imagesArray;
    NSMutableArray *favImageArray;
    
    UITableView *tableViewObj;
    IBOutlet UIView *dpviewObj;
    NSInteger currentOffset;
    UILabel * NoFavoritesfoundlabel;
}

@property(nonatomic, assign) NSInteger currentOffset;
@property (nonatomic,retain) IBOutlet UITableView *tableViewObj;
@property (nonatomic,retain) NSMutableArray *imagesArray;
@property (nonatomic,retain) NSMutableArray *favImageArray;
@property (nonatomic,retain) UIActivityIndicatorView *spinner;
@property (nonatomic,retain) UIImageView *actBgimg;
@property (nonatomic,retain) UILabel * NoFavoritesfoundlabel;

-(IBAction)btnPhotosClick:(id)sender;
-(IBAction)btnAllNewsClick:(id)sender;
-(IBAction)btnFavClick:(id)sender;
-(IBAction)btnLatestClick:(id)sender;

@end

