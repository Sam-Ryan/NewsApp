
#import "InfoViewController.h"
#import "MKInfoPanel.h"
#import "UIImageView+WebCache.h"
#import "ASIFormDataRequest.h"
#import "Reachability.h"
#import "UIDevice+Res.h"
#import "AppDelegate.h"


@interface InfoViewController ()
{
    Reachability *internetReachable;
    NetworkStatus internetStatus;
    GADBannerView *bannerView_;
}
@end

@implementation InfoViewController

@synthesize actBgimg,spinner,allArrayData;
@synthesize logImgeView,appNameLbl,emailLbl,urlLbl,detailsTextView;

- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    //ShowAds
    // Replace this ad unit ID with your own ad unit ID.christmas
    
    appDelegate = [[UIApplication sharedApplication] delegate];
    
    internetReachable = [Reachability reachabilityForInternetConnection];
    internetStatus = [internetReachable currentReachabilityStatus];
    
    //spinnerBg
    UIImage *spinnerBg=[UIImage imageNamed:@"spinnerbg.png"];
    actBgimg=[[UIImageView alloc]initWithImage:spinnerBg];
    //actBgimg.frame=CGRectMake(130, 238, 60, 60);
    actBgimg.center = self.view.center;
    actBgimg.layer.masksToBounds = YES;
    actBgimg.layer.cornerRadius = 7.0;
    actBgimg.alpha = 1.0;
    [self.view addSubview:actBgimg];
    actBgimg.hidden = YES;
    
    //AcivityIndicator
    spinner = [[UIActivityIndicatorView alloc] initWithActivityIndicatorStyle:UIActivityIndicatorViewStyleWhiteLarge];
    //spinner.frame = CGRectMake(141, 250,37,37);
    spinner.center=self.view.center;
    [self.view addSubview:spinner];
    spinner.hidden = YES;
    
}

-(void)startSpinner
{
    actBgimg.hidden = NO;
    spinner.hidden = NO;
    [spinner startAnimating];
    [self.view setUserInteractionEnabled:NO];
}

-(void)stopSpinner
{
    actBgimg.hidden = YES;
    spinner.hidden = YES;
    [spinner stopAnimating];
    [self.view setUserInteractionEnabled:YES];
}

- (void)viewWillAppear:(BOOL)animated {
    
    [super viewWillAppear:animated];
    
    bannerView_ = [[GADBannerView alloc] initWithAdSize:kGADAdSizeBanner];
    bannerView_.adUnitID = appDelegate.bannerViewAdUnitID;
    bannerView_.rootViewController = self;
    if (UI_USER_INTERFACE_IDIOM() == UIUserInterfaceIdiomPad)
    {
        bannerView_.frame = CGRectMake(0, self.view.frame.size.height - 50, self.view.frame.size.width, 50);
    }
    else
    {
        if ([UIDevice type] == iPhone4) {
            bannerView_.frame = CGRectMake(0, self.view.frame.size.height - 50, 320, 50);
        }
        else if ([UIDevice type] == iPhone5) {
            bannerView_.frame = CGRectMake(0, self.view.frame.size.height - 50, 320, 50);
        }
        else if ([UIDevice type] == iPhone6) {
            bannerView_.frame = CGRectMake(0, self.view.frame.size.height - 50, 375, 50);
        }
        else if ([UIDevice type] == iPhone6Plus) {
            bannerView_.frame = CGRectMake(0, self.view.frame.size.height - 50, 414, 50);
        }
        
    }
    [self.view addSubview:bannerView_];
    [bannerView_ loadRequest:[GADRequest request]];
    
    self.navigationController.navigationBarHidden =YES;
    
    allArrayData = [[NSMutableArray alloc]init];
    
    [self getLatest];
    
   
}

-(void)getLatest
{
    if (internetStatus == 0)
    {
        [self Networkfailure];
    }
    else
    {
        [self startSpinner];
        
        [allArrayData removeAllObjects];
        
        NSString *requestUrl = [ NSString stringWithFormat:@"%@api.php?apps_details",appDelegate.domainURL];
        
        NSURL *getLatestUrl = [NSURL URLWithString:requestUrl];
        ASIHTTPRequest *request = [ASIHTTPRequest requestWithURL:getLatestUrl];
        [request setDelegate:self];
        [request startAsynchronous];
    }
}

- (void)requestFinished:(ASIHTTPRequest *)response
{
    // Use when fetching binary data
    NSData *responseData = [response responseData];
    NSDictionary *detailsDict = [NSJSONSerialization JSONObjectWithData:responseData options:NSJSONReadingMutableContainers error:nil];
    
    NSArray *storeArr = [detailsDict valueForKey:@"NewsApp"];
    //NSLog(@"storeArr = %@",storeArr);
    if (storeArr.count > 0) {
        [self stopSpinner];
    }
    
    //[allArrayData removeAllObjects];
    
    for (int i=0; i<storeArr.count; i++)
    {
        NSDictionary *storeDict = [storeArr objectAtIndex:i];
        [allArrayData addObject:storeDict];
    }
     if (allArrayData.count > 0) {
        // Add Logo
        NSString *str = [NSString stringWithFormat:@"%@upload/%@",appDelegate.domainURL,[[allArrayData lastObject] valueForKey:@"app_logo"]];
        
         
         
        [logImgeView setImageWithURL:[NSURL URLWithString:str]];
        
//        UIActivityIndicatorView *activityIndicator = [[UIActivityIndicatorView alloc] initWithActivityIndicatorStyle:UIActivityIndicatorViewStyleWhiteLarge];
//        activityIndicator.center = logImgeView.center;
//        activityIndicator.hidesWhenStopped = YES;
//
//        [logImgeView setImageWithURL:[NSURL URLWithString:str] placeholderImage:[UIImage imageNamed:@"placeholder.png"] success:^(UIImage *image, BOOL cached) {
//            [activityIndicator  removeFromSuperview];
//        } failure:^(NSError *error) {
//            [activityIndicator  removeFromSuperview];
//        }];
//
//        [logImgeView addSubview:activityIndicator];
//        [activityIndicator startAnimating];
         
        // NSLog(@"allArrayData = %@",allArrayData);
        appNameLbl.text = [[allArrayData lastObject] valueForKey:@"app_name"];
        
        emailLbl.text = [[allArrayData lastObject] valueForKey:@"app_email"];
        
        urlLbl.text = [[allArrayData lastObject] valueForKey:@"app_website"];
        
        detailsTextView.text = [[allArrayData lastObject] valueForKey:@"app_description"];
    }

    
}

- (void)requestFailed:(ASIHTTPRequest *)response
{
    [self stopSpinner];
    //    NSError *error = [response error];
    //NSString *tagStr = [NSString stringWithFormat:@"-%ld",(long)response.tag];
    NSDictionary* dict = [NSDictionary dictionaryWithObject: response forKey:@"index"];
    
    NSLog(@"requestFailed = %@",dict);
}

-(void)Networkfailure
{
    [self stopSpinner];
    [MKInfoPanel showPanelInView:self.view type:MKInfoPanelTypeError title:@"Network failure!" subtitle:@"Internet connection not available!." hideAfter:2.0];
}

-(IBAction)btnBackClick:(id)sender
{
    [self.navigationController popViewControllerAnimated:YES];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
