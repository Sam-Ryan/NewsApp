//
//  ViewController.m
//  News
//
//  Created by Vishal on 5/1/15.
//  Copyright (c) 2015 Vishal. All rights reserved.
//

#import "ViewController.h"
#import "MKInfoPanel.h"
#import "FMDatabase.h"
#import "FMResultSet.h"
#import "UIImageView+WebCache.h"
#import "ASIFormDataRequest.h"
#import "Reachability.h"

#import "DetailView.h"
#import "ListViewDetails.h"
#import "UIDevice+Res.h"

@interface ViewController ()
{
    Reachability *internetReachable;
    NetworkStatus internetStatus;
    GADBannerView *bannerView_;
}
@end

@implementation ViewController

@synthesize actBgimg,spinner;
@synthesize imagesArray,tableViewObj,currentOffset;
@synthesize favImageArray;
@synthesize NoFavoritesfoundlabel;

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
    
    appDelegate = [[UIApplication sharedApplication] delegate];
    
    internetReachable = [Reachability reachabilityForInternetConnection];
    internetStatus = [internetReachable currentReachabilityStatus];
    
    if (UI_USER_INTERFACE_IDIOM() == UIUserInterfaceIdiomPad)
    {
        infoViewObj =[[InfoViewController alloc]initWithNibName:@"InfoViewController_iPad" bundle:nil];
    }
    else
    {
        if ([UIDevice type] == iPhone4) {
            infoViewObj =[[InfoViewController alloc]initWithNibName:@"InfoViewController_4" bundle:nil];
        }
        else if ([UIDevice type] == iPhone5) {
            infoViewObj =[[InfoViewController alloc]initWithNibName:@"InfoViewController" bundle:nil];
        }
        else if ([UIDevice type] == iPhone6) {
            infoViewObj =[[InfoViewController alloc]initWithNibName:@"InfoViewController_6" bundle:nil];
        }
        else if ([UIDevice type] == iPhone6Plus) {
            infoViewObj =[[InfoViewController alloc]initWithNibName:@"InfoViewController_6Plus" bundle:nil];
        }
    }
    
    //spinnerBg
    UIImage *spinnerBg=[UIImage imageNamed:@"spinnerbg.png"];
    actBgimg=[[UIImageView alloc]initWithImage:spinnerBg];
    //actBgimg.frame=CGRectMake(130, 238, 60, 60);
    actBgimg.center = self.view.center;
    actBgimg.layer.masksToBounds = YES;
    actBgimg.layer.cornerRadius = 7.0;
    actBgimg.alpha = 1.0;
    [self.view addSubview:actBgimg];
    actBgimg.hidden = YES;
    
    //AcivityIndicator
    spinner = [[UIActivityIndicatorView alloc] initWithActivityIndicatorStyle:UIActivityIndicatorViewStyleWhiteLarge];
    //spinner.frame = CGRectMake(141, 250,37,37);
    spinner.center=self.view.center;
    [self.view addSubview:spinner];
    spinner.hidden = YES;
    
    
    self.tableViewObj.showsVerticalScrollIndicator = NO;
    self.tableViewObj.showsVerticalScrollIndicator = NO;
    
    if (UI_USER_INTERFACE_IDIOM() == UIUserInterfaceIdiomPad)
    {
        self.tableViewObj.rowHeight = 100.0f;
    }
    else
    {
        self.tableViewObj.rowHeight = 85.0f;
    }

    
    dpviewObj.hidden = YES;
    
    NSNumber *value = [NSNumber numberWithInt:UIInterfaceOrientationMaskPortrait];
    [[UIDevice currentDevice] setValue:value forKey:@"orientation"];
    
    [btnLatest setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    [btnAllNews setTitleColor:[UIColor lightGrayColor] forState:UIControlStateNormal];
    [btnMyFavorites setTitleColor:[UIColor lightGrayColor] forState:UIControlStateNormal];
    selImageObj.frame = CGRectMake(0, 111, 103, 3);
    tableViewObj.hidden = NO;
    tableViewObj.backgroundColor = [UIColor clearColor];
    
    // This will remove extra separators from tableview
    tableViewObj.tableFooterView = [[UIView alloc] initWithFrame:CGRectZero];

}

-(void)startSpinner
{
    actBgimg.hidden = NO;
    spinner.hidden = NO;
    [spinner startAnimating];
    [self.view setUserInteractionEnabled:NO];
}

-(void)stopSpinner
{
    actBgimg.hidden = YES;
    spinner.hidden = YES;
    [spinner stopAnimating];
    [self.view setUserInteractionEnabled:YES];
}

-(void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
    self.navigationController.navigationBarHidden =YES;
    
    bannerView_ = [[GADBannerView alloc] initWithAdSize:kGADAdSizeBanner];
    bannerView_.adUnitID = appDelegate.bannerViewAdUnitID;
    bannerView_.rootViewController = self;
    
    if (UI_USER_INTERFACE_IDIOM() == UIUserInterfaceIdiomPad)
    {
        bannerView_.frame = CGRectMake(0, self.view.frame.size.height - 50, self.view.frame.size.width, 50);
    }
    else
    {
        if ([UIDevice type] == iPhone4) {
            bannerView_.frame = CGRectMake(0, self.view.frame.size.height - 50, 320, 50);
        }
        else if ([UIDevice type] == iPhone5) {
            bannerView_.frame = CGRectMake(0, self.view.frame.size.height - 50, 320, 50);
        }
        else if ([UIDevice type] == iPhone6) {
            bannerView_.frame = CGRectMake(0, self.view.frame.size.height - 50, 375, 50);
        }
        else if ([UIDevice type] == iPhone6Plus) {
            bannerView_.frame = CGRectMake(0, self.view.frame.size.height - 50, 414, 50);
        }
    }
    
    [self.view addSubview:bannerView_];
    [bannerView_ loadRequest:[GADRequest request]];
    
    
    NoFavoritesfoundlabel = [[UILabel alloc] init];
    
    favImageArray = [[[NSMutableArray alloc]init] retain];
    imagesArray = [[[NSMutableArray alloc]init] retain];
    
    NSString *SelectScreenValue = [[NSUserDefaults standardUserDefaults] stringForKey:@"SelectScreen"];

    if ([SelectScreenValue isEqualToString:@"Favourites"])
    {
         NoFavoritesfoundlabel.hidden = YES;
        [self btnFavClick:nil];
        [tableViewObj reloadData];
    }
    else if ([SelectScreenValue isEqualToString:@"Latest"])
    {
        NoFavoritesfoundlabel.hidden = YES;
        [self btnLatestClick:nil];
        [tableViewObj reloadData];
    }
    else if ([SelectScreenValue isEqualToString:@"AllNews"])
    {
        NoFavoritesfoundlabel.hidden = YES;
        [self btnAllNewsClick:nil];
        [tableViewObj reloadData];
    }
    else
    {
        NoFavoritesfoundlabel.hidden = YES;
        [self getLatest];
    }
}

-(void)getLatest
{
    if (internetStatus == 0)
    {
        [self Networkfailure];
    }
    else
    {
        [self startSpinner];
        [imagesArray removeAllObjects];
        
        NSString *requestUrl = [ NSString stringWithFormat:@"%@api.php?latest_news=10",appDelegate.domainURL];
        NSURL *getLatestUrl = [NSURL URLWithString:requestUrl];
        ASIHTTPRequest *request = [ASIHTTPRequest requestWithURL:getLatestUrl];
        [request setDelegate:self];
        [request startAsynchronous];
    }
}

-(void)getAllNews
{
    if (internetStatus == 0)
    {
        [self Networkfailure];
    }
    else
    {
        [self startSpinner];
        
        if (imagesArray.count > 0) {
            [imagesArray removeAllObjects];
        }
        
        NSString *requestUrl = [ NSString stringWithFormat:@"%@api.php",appDelegate.domainURL];
        NSURL *getLatestUrl = [NSURL URLWithString:requestUrl];
        ASIHTTPRequest *request = [ASIHTTPRequest requestWithURL:getLatestUrl];
        [request setDelegate:self];
        [request startAsynchronous];
    }
}


- (void)requestFinished:(ASIHTTPRequest *)response
{
    // Use when fetching binary data
    NSData *responseData = [response responseData];
    NSDictionary *detailsDict = [NSJSONSerialization JSONObjectWithData:responseData options:NSJSONReadingMutableContainers error:nil];

    NSArray *storeArr = [detailsDict valueForKey:@"NewsApp"];
    
    if (storeArr.count > 0) {
        NoFavoritesfoundlabel.hidden = YES;
        [self stopSpinner];
    }
    
    for (int i=0; i<storeArr.count; i++)
    {
        NSDictionary *storeDict = [storeArr objectAtIndex:i];
        [imagesArray addObject:storeDict];
    }
    
    [tableViewObj reloadData];
}

- (void)requestFailed:(ASIHTTPRequest *)response
{
    [self stopSpinner];
    //NSError *error = [response error];
    
    //NSString *tagStr = [NSString stringWithFormat:@"-%ld",(long)response.tag];

    NSDictionary* dict = [NSDictionary dictionaryWithObject: response forKey:@"index"];
    NSLog(@"requestFailed = %@",dict);
}

-(void)Networkfailure
{
    [self stopSpinner];
    [MKInfoPanel showPanelInView:self.view type:MKInfoPanelTypeError title:@"Network failure!" subtitle:@"Internet connection not available!." hideAfter:2.0];
}

//Table Start////
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return [imagesArray count];
}


- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *CellIdentifier = @"Cell";
    
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
    UIImageView * imageView ;
    
    if (cell == nil)
    {
        if (UI_USER_INTERFACE_IDIOM() == UIUserInterfaceIdiomPad)
        {
            imageView = [[UIImageView alloc] initWithFrame:CGRectMake(20, 5, 70, 70)];
        }
        else
        {
            imageView = [[UIImageView alloc] initWithFrame:CGRectMake(10, 8, 70, 70)];
        }
        
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CellIdentifier];
    }
    else
    {
        if (UI_USER_INTERFACE_IDIOM() == UIUserInterfaceIdiomPad)
        {
            imageView = [[UIImageView alloc] initWithFrame:CGRectMake(20, 5, 70, 70)];
        }
        else
        {
            imageView = [[UIImageView alloc] initWithFrame:CGRectMake(10, 8, 70, 70)];
        }
        
        cell = nil;
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CellIdentifier];
    }

    NSDictionary *tempObj = [imagesArray objectAtIndex:indexPath.row];

    
    if([tempObj valueForKey:@"news_description"] != nil)
    {
        // The key existed...
        CALayer * l = [imageView layer];
        [l setMasksToBounds:YES];
        [l setCornerRadius:10.0];
        
        // You can even add a border
        [l setBorderWidth:2.0];
        [l setBorderColor:[[UIColor lightGrayColor] CGColor]];
        
        NSString *str = [NSString stringWithFormat:@"%@upload/thumbs/%@",appDelegate.domainURL,[tempObj valueForKey:@"news_image"]];

        [imageView setImageWithURL:[NSURL URLWithString:str]];
        
        imageView.layer.backgroundColor=[[UIColor clearColor] CGColor];
        imageView.layer.cornerRadius=35;
        imageView.layer.borderWidth=5.0;
        imageView.layer.masksToBounds = YES;
        [imageView.layer setBorderColor:[UIColor colorWithWhite:1.0f alpha:0.5f].CGColor];
        
        [cell.contentView addSubview:imageView];
        
        UILabel * lblTemp = [[UILabel alloc] init];
        lblTemp.textColor = [UIColor colorWithRed:252/255.0 green:98/255.0 blue:7/255.0 alpha:1.0];
      
        if (UI_USER_INTERFACE_IDIOM() == UIUserInterfaceIdiomPad)
        {
            lblTemp.frame = CGRectMake(125, 15, 620, 25);
            lblTemp.font =  [UIFont fontWithName:@"Arial-BoldMT" size:22];
        }
        else
        {
            lblTemp.frame = CGRectMake(90, 15, 200, 18);
            lblTemp.font =  [UIFont fontWithName:@"Arial-BoldMT" size:17];
        }
        
        lblTemp.text = [tempObj valueForKey:@"category_name"];
        [cell.contentView addSubview:lblTemp];
        
        
        UILabel * lblTemp2 = [[UILabel alloc] init];
        //lblTemp2.lineBreakMode = NSLineBreakByWordWrapping;
        lblTemp2.numberOfLines = 5;
        lblTemp2.textColor = [UIColor colorWithRed:81/255.0 green:81/255.0 blue:81/255.0 alpha:1.0];
        if (UI_USER_INTERFACE_IDIOM() == UIUserInterfaceIdiomPad)
        {
            lblTemp2.frame = CGRectMake(125, 40, 620, 45);
            lblTemp2.font =  [UIFont fontWithName:@"Arial" size:20];
        }
        else
        {
            lblTemp2.frame = CGRectMake(90, 35, 220, 30);
            lblTemp2.font =  [UIFont fontWithName:@"Arial" size:13];
        }
        
        lblTemp2.text = [tempObj valueForKey:@"news_heading"];

        [cell.contentView addSubview:lblTemp2];
    }
    else {
        // No joy...

        CALayer * l = [imageView layer];
        [l setMasksToBounds:YES];
        [l setCornerRadius:10.0];
        
        // You can even add a border
        [l setBorderWidth:2.0];
        [l setBorderColor:[[UIColor lightGrayColor] CGColor]];
        
        NSString *str = [NSString stringWithFormat:@"%@upload/category/%@",appDelegate.domainURL,[tempObj valueForKey:@"category_image"]];

        [imageView setImageWithURL:[NSURL URLWithString:str]];
    
        imageView.layer.backgroundColor=[[UIColor clearColor] CGColor];
        imageView.layer.cornerRadius=45;
        imageView.layer.borderWidth=5.0;
        imageView.layer.masksToBounds = YES;
        [imageView.layer setBorderColor:[UIColor colorWithWhite:1.0f alpha:0.5f].CGColor];
    
        [cell.contentView addSubview:imageView];
        
        UILabel * lblTemp = [[UILabel alloc] init];
        lblTemp.numberOfLines = 5;
        lblTemp.font =  [UIFont fontWithName:@"Arial-BoldMT" size:16];
        lblTemp.textColor = [UIColor colorWithRed:252/255.0 green:98/255.0 blue:7/255.0 alpha:1.0];
        
        if (UI_USER_INTERFACE_IDIOM() == UIUserInterfaceIdiomPad)
        {
            lblTemp.frame = CGRectMake(125, 30, 620, 35);
            lblTemp.font =  [UIFont fontWithName:@"Arial-BoldMT" size:25];
        }
        else
        {
            lblTemp.frame = CGRectMake(90, 35, 220, 18);
            lblTemp.font =  [UIFont fontWithName:@"Arial-BoldMT" size:17];
        }
        lblTemp.text = [tempObj valueForKey:@"category_name"];
        [cell.contentView addSubview:lblTemp];
    }
    
    [cell setBackgroundColor:[UIColor clearColor]];
   
    
    
    return cell;
    
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    NSDictionary *tempObj = [imagesArray objectAtIndex:indexPath.row];

    NSString *SelectScreenValue = [[NSUserDefaults standardUserDefaults] stringForKey:@"SelectScreen"];
    
    if ([SelectScreenValue isEqualToString:@"Favourites"])
    {
        //NSLog(@"Favourites");
        NSString *valueToSave = @"Favourites";
        [[NSUserDefaults standardUserDefaults] setObject:valueToSave forKey:@"SelectScreen"];
        [[NSUserDefaults standardUserDefaults] synchronize];
        
        NSString * catSelObj = [[NSString alloc] initWithFormat:@"%@",[tempObj valueForKey:@"cid"]];
        
        ListViewDetails * detailsView;
        
        if (UI_USER_INTERFACE_IDIOM() == UIUserInterfaceIdiomPad)
        {
            detailsView = [[ListViewDetails alloc] initWithNibName:@"ListViewDetails_iPad" bundle:nil];
        }
        else
        {
            if ([UIDevice type] == iPhone4) {
                detailsView = [[ListViewDetails alloc] initWithNibName:@"ListViewDetails_4" bundle:nil];
            }
            else if ([UIDevice type] == iPhone5) {
                detailsView = [[ListViewDetails alloc] initWithNibName:@"ListViewDetails" bundle:nil];
            }
            else if ([UIDevice type] == iPhone6) {
                detailsView = [[ListViewDetails alloc] initWithNibName:@"ListViewDetails_6" bundle:nil];
            }
            else if ([UIDevice type] == iPhone6Plus) {
                detailsView = [[ListViewDetails alloc] initWithNibName:@"ListViewDetails_6Plus" bundle:nil];
            }
        }
        
        //ListViewDetails * detailsView = [[ListViewDetails alloc] initWithNibName:@"ListViewDetails" bundle:nil];
        detailsView.CatIdSelectFor = catSelObj;
        detailsView.SetIndex = (long)indexPath.row;
        detailsView.CatScreenName = @"Favourites";
        [self.navigationController pushViewController:detailsView animated:YES];
        
    }
    else if ([SelectScreenValue isEqualToString:@"Latest"])
    {
        //NSLog(@"Latest");
        NSString *valueToSave = @"Latest";
        [[NSUserDefaults standardUserDefaults] setObject:valueToSave forKey:@"SelectScreen"];
        [[NSUserDefaults standardUserDefaults] synchronize];
        
        
        NSString * catSelObj = [[NSString alloc] initWithFormat:@"%@",[tempObj valueForKey:@"cid"]];
        
        ListViewDetails * detailsView;
        
        if (UI_USER_INTERFACE_IDIOM() == UIUserInterfaceIdiomPad)
        {
            detailsView = [[ListViewDetails alloc] initWithNibName:@"ListViewDetails_iPad" bundle:nil];
        }
        else
        {
            if ([UIDevice type] == iPhone4) {
                detailsView = [[ListViewDetails alloc] initWithNibName:@"ListViewDetails_4" bundle:nil];
            }
            else if ([UIDevice type] == iPhone5) {
                detailsView = [[ListViewDetails alloc] initWithNibName:@"ListViewDetails" bundle:nil];
            }
            else if ([UIDevice type] == iPhone6) {
                detailsView = [[ListViewDetails alloc] initWithNibName:@"ListViewDetails_6" bundle:nil];
            }
            else if ([UIDevice type] == iPhone6Plus) {
                detailsView = [[ListViewDetails alloc] initWithNibName:@"ListViewDetails_6Plus" bundle:nil];
            }
        }
        //ListViewDetails * detailsView = [[ListViewDetails alloc] initWithNibName:@"ListViewDetails" bundle:nil];
        detailsView.CatIdSelectFor = catSelObj;
        detailsView.SetIndex = (long)indexPath.row;
        detailsView.CatScreenName = @"Latest";
        [self.navigationController pushViewController:detailsView animated:YES];
    }
    else
    {
        //NSLog(@"AllNews");
        NSString *valueToSave = @"AllNews";
        [[NSUserDefaults standardUserDefaults] setObject:valueToSave forKey:@"SelectScreen"];
        [[NSUserDefaults standardUserDefaults] synchronize];
        
        NSString * catSelObj = [[NSString alloc] initWithFormat:@"%@",[tempObj valueForKey:@"cid"]];
        
        DetailView * detailsView;
        
        if (UI_USER_INTERFACE_IDIOM() == UIUserInterfaceIdiomPad)
        {
            detailsView = [[DetailView alloc] initWithNibName:@"DetailView_iPad" bundle:nil];
        }
        else
        {
            if ([UIDevice type] == iPhone4) {
                detailsView = [[DetailView alloc] initWithNibName:@"DetailView_4" bundle:nil];
            }
            else if ([UIDevice type] == iPhone5) {
                detailsView = [[DetailView alloc] initWithNibName:@"DetailView" bundle:nil];
            }
            else if ([UIDevice type] == iPhone6) {
                detailsView = [[DetailView alloc] initWithNibName:@"DetailView_6" bundle:nil];
            }
            else if ([UIDevice type] == iPhone6Plus) {
                detailsView = [[DetailView alloc] initWithNibName:@"DetailView_6Plus" bundle:nil];
            }
        }
        //DetailView * detailsView = [[DetailView alloc] initWithNibName:@"DetailView" bundle:nil];
        detailsView.CatIdSelect = catSelObj;
        detailsView.CatScreenName = @"AllNews";
        [self.navigationController pushViewController:detailsView animated:YES];
    }
}

//- (CGFloat)tableView:(UITableView *)tableView heightForFooterInSection:(NSInteger)section {
//    // This will create a "invisible" footer
//    return 0.01f;
//}
//
//- (UIView *)tableView:(UITableView *)tableView viewForFooterInSection:(NSInteger)section
//{
//    return [UIView new];
//
//    // If you are not using ARC:
//    // return [[UIView new] autorelease];
//}

- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section {
    // This will create a "invisible" footer
    return 0.01f;
}

- (UIView *)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section
{
    return [UIView new];
    
    // If you are not using ARC:
    // return [[UIView new] autorelease];
}

-(IBAction)btnLatestClick:(id)sender
{
    NSString *valueToSave = @"Latest";
    [[NSUserDefaults standardUserDefaults] setObject:valueToSave forKey:@"SelectScreen"];
    [[NSUserDefaults standardUserDefaults] synchronize];
    
    if (UI_USER_INTERFACE_IDIOM() == UIUserInterfaceIdiomPad)
    {
        [btnLatest setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
        [btnAllNews setTitleColor:[UIColor lightGrayColor] forState:UIControlStateNormal];
        [btnMyFavorites setTitleColor:[UIColor lightGrayColor] forState:UIControlStateNormal];
        selImageObj.frame = CGRectMake(0, 120, 256, 4);
    }
    else
    {
        if ([UIDevice type] == iPhone4) {
            [btnLatest setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
            [btnAllNews setTitleColor:[UIColor lightGrayColor] forState:UIControlStateNormal];
            [btnMyFavorites setTitleColor:[UIColor lightGrayColor] forState:UIControlStateNormal];
            selImageObj.frame = CGRectMake(0, 111, 103, 3);
            
        }
        else if ([UIDevice type] == iPhone5) {
            //tableViewObj.hidden = YES;
            
            [btnLatest setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
            [btnAllNews setTitleColor:[UIColor lightGrayColor] forState:UIControlStateNormal];
            [btnMyFavorites setTitleColor:[UIColor lightGrayColor] forState:UIControlStateNormal];
            selImageObj.frame = CGRectMake(0, 111, 103, 3);
        }
        else if ([UIDevice type] == iPhone6) {
            //tableViewObj.hidden = YES;
            [btnLatest setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
            [btnAllNews setTitleColor:[UIColor lightGrayColor] forState:UIControlStateNormal];
            [btnMyFavorites setTitleColor:[UIColor lightGrayColor] forState:UIControlStateNormal];
            selImageObj.frame = CGRectMake(0, 111, 125, 3);
        }
        else if ([UIDevice type] == iPhone6Plus) {
            //tableViewObj.hidden = YES;
            [btnLatest setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
            [btnAllNews setTitleColor:[UIColor lightGrayColor] forState:UIControlStateNormal];
            [btnMyFavorites setTitleColor:[UIColor lightGrayColor] forState:UIControlStateNormal];
            selImageObj.frame = CGRectMake(0, 111, 138, 3);
        }

    }
    
    [self getLatest];
    [tableViewObj reloadData];
}


-(IBAction)btnAllNewsClick:(id)sender
{
    NoFavoritesfoundlabel.hidden = YES;
    
    NSString *valueToSave = @"AllNews";
    [[NSUserDefaults standardUserDefaults] setObject:valueToSave forKey:@"SelectScreen"];
    [[NSUserDefaults standardUserDefaults] synchronize];
    
    if (UI_USER_INTERFACE_IDIOM() == UIUserInterfaceIdiomPad)
    {
        [btnAllNews setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
        [btnLatest setTitleColor:[UIColor lightGrayColor] forState:UIControlStateNormal];
        [btnMyFavorites setTitleColor:[UIColor lightGrayColor] forState:UIControlStateNormal];
        selImageObj.frame = CGRectMake(257, 120, 256, 4);
        
    }
    else
    {
        if ([UIDevice type] == iPhone4) {
            [btnAllNews setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
            [btnLatest setTitleColor:[UIColor lightGrayColor] forState:UIControlStateNormal];
            [btnMyFavorites setTitleColor:[UIColor lightGrayColor] forState:UIControlStateNormal];
            selImageObj.frame = CGRectMake(104, 111, 103, 3);
        }
        else if ([UIDevice type] == iPhone5) {
            [btnAllNews setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
            [btnLatest setTitleColor:[UIColor lightGrayColor] forState:UIControlStateNormal];
            [btnMyFavorites setTitleColor:[UIColor lightGrayColor] forState:UIControlStateNormal];
            selImageObj.frame = CGRectMake(104, 111, 103, 3);
        }
        else if ([UIDevice type] == iPhone6) {
            [btnAllNews setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
            [btnLatest setTitleColor:[UIColor lightGrayColor] forState:UIControlStateNormal];
            [btnMyFavorites setTitleColor:[UIColor lightGrayColor] forState:UIControlStateNormal];
            selImageObj.frame = CGRectMake(125, 111, 125, 3);
        }
        else if ([UIDevice type] == iPhone6Plus) {
            [btnAllNews setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
            [btnLatest setTitleColor:[UIColor lightGrayColor] forState:UIControlStateNormal];
            [btnMyFavorites setTitleColor:[UIColor lightGrayColor] forState:UIControlStateNormal];
            selImageObj.frame = CGRectMake(140, 111, 136, 3);
        }
    }
    [self getAllNews];
    [tableViewObj reloadData];
}

-(IBAction)btnPhotosClick:(id)sender
{
    NoFavoritesfoundlabel.hidden = YES;
    
    [btnAllNews setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    [btnLatest setTitleColor:[UIColor lightGrayColor] forState:UIControlStateNormal];
    [btnMyFavorites setTitleColor:[UIColor lightGrayColor] forState:UIControlStateNormal];
    selImageObj.frame = CGRectMake(104, 111, 103, 3);
}

-(NSString *) databasePath
{
    NSArray *paths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
    NSString *documentsDir = [paths objectAtIndex:0];
    NSString *dbPath = [documentsDir stringByAppendingPathComponent:@"News.sqlite"];
    return dbPath;
}

-(IBAction)btnFavClick:(id)sender
{
    NoFavoritesfoundlabel.hidden = YES;
    
    NSString *valueToSave = @"Favourites";
    [[NSUserDefaults standardUserDefaults] setObject:valueToSave forKey:@"SelectScreen"];
    [[NSUserDefaults standardUserDefaults] synchronize];
    
    
    [tableViewObj reloadData];
    
    [self.favImageArray removeAllObjects];
    [self.imagesArray removeAllObjects];
    
    tableViewObj.hidden = NO;
    
    if (UI_USER_INTERFACE_IDIOM() == UIUserInterfaceIdiomPad)
    {
        [btnMyFavorites setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
        [btnLatest setTitleColor:[UIColor lightGrayColor] forState:UIControlStateNormal];
        [btnAllNews setTitleColor:[UIColor lightGrayColor] forState:UIControlStateNormal];
        selImageObj.frame = CGRectMake(512, 120, 256, 4);
    }
    else
    {
        if ([UIDevice type] == iPhone4) {
            [btnMyFavorites setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
            [btnLatest setTitleColor:[UIColor lightGrayColor] forState:UIControlStateNormal];
            [btnAllNews setTitleColor:[UIColor lightGrayColor] forState:UIControlStateNormal];
            selImageObj.frame = CGRectMake(209, 111, 111, 3);
        }
        else if ([UIDevice type] == iPhone5) {
            [btnMyFavorites setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
            [btnLatest setTitleColor:[UIColor lightGrayColor] forState:UIControlStateNormal];
            [btnAllNews setTitleColor:[UIColor lightGrayColor] forState:UIControlStateNormal];
            selImageObj.frame = CGRectMake(209, 111, 111, 3);
        }
        else if ([UIDevice type] == iPhone6) {
            [btnMyFavorites setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
            [btnLatest setTitleColor:[UIColor lightGrayColor] forState:UIControlStateNormal];
            [btnAllNews setTitleColor:[UIColor lightGrayColor] forState:UIControlStateNormal];
            selImageObj.frame = CGRectMake(250, 111, 250, 3);
        }
        else if ([UIDevice type] == iPhone6Plus) {
            [btnMyFavorites setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
            [btnLatest setTitleColor:[UIColor lightGrayColor] forState:UIControlStateNormal];
            [btnAllNews setTitleColor:[UIColor lightGrayColor] forState:UIControlStateNormal];
            selImageObj.frame = CGRectMake(278, 111, 136, 3);
    }
    }
    
    //NSLog(@"database Path = %@",[self databasePath]);
    FMDatabase *database = [FMDatabase databaseWithPath:[self databasePath]];
    [database open];
    NSString *queryStr = [NSString stringWithFormat:@"SELECT * from Favorite"];
    FMResultSet *resultStr = [database executeQuery:queryStr];
    
    
    while ([resultStr next])
    {
        NSMutableDictionary *xyz=[[NSMutableDictionary alloc] init];
       
        // NSData from the Base64 encoded str
        NSData * nsdataFromBase64String1 = [[NSData alloc] initWithBase64EncodedString:[resultStr stringForColumn:@"categoryname"] options:0];
        NSData * nsdataFromBase64String2 = [[NSData alloc] initWithBase64EncodedString:[resultStr stringForColumn:@"newsheading"] options:0];
        NSData * nsdataFromBase64String3 = [[NSData alloc] initWithBase64EncodedString:[resultStr stringForColumn:@"newsdesc"] options:0];
        // Decoded NSString from the NSData
        
        NSString *categoryname_base64Decoded = [[NSString alloc] initWithData:nsdataFromBase64String1 encoding:NSUTF8StringEncoding];
        NSString *newsheading_base64Decoded = [[NSString alloc] initWithData:nsdataFromBase64String2 encoding:NSUTF8StringEncoding];
        NSString *newsdesc_base64Decoded = [[NSString alloc] initWithData:nsdataFromBase64String3 encoding:NSUTF8StringEncoding];
        //NSLog(@"Decoded: %@", newsdesc_base64Decoded);
        
        [xyz setValue:[resultStr stringForColumn:@"nid"] forKey:@"nid"];
        [xyz setValue:[resultStr stringForColumn:@"catid"] forKey:@"id"];
        [xyz setValue:[resultStr stringForColumn:@"cid"] forKey:@"cid"];
        [xyz setValue:categoryname_base64Decoded forKey:@"category_name"];
        [xyz setValue:newsheading_base64Decoded forKey:@"news_heading"];
        [xyz setValue:[resultStr stringForColumn:@"newsimage"] forKey:@"news_image"];
        [xyz setValue:newsdesc_base64Decoded forKey:@"news_description"];
        [xyz setValue:[resultStr stringForColumn:@"newsdate"] forKey:@"news_date"];
        
        [self.favImageArray addObject:xyz];
        [self.imagesArray addObject:xyz];
    }
 
    [tableViewObj reloadData];
    
    NoFavoritesfoundlabel.hidden = YES;
    
    if (self.imagesArray.count == 0)
    {
        NoFavoritesfoundlabel.hidden = NO;
        
        [NoFavoritesfoundlabel setTextColor:[UIColor lightGrayColor]];
        [NoFavoritesfoundlabel setText:@"No Favorites found."];
        [NoFavoritesfoundlabel sizeToFit];
        NoFavoritesfoundlabel.frame = CGRectMake((self.tableViewObj.bounds.size.width - NoFavoritesfoundlabel.bounds.size.width) / 2.0f, (self.tableViewObj.rowHeight - NoFavoritesfoundlabel.bounds.size.height) / 2.0f+100, NoFavoritesfoundlabel.bounds.size.width,  NoFavoritesfoundlabel.bounds.size.height);
        [self.tableViewObj insertSubview:NoFavoritesfoundlabel atIndex:0];
    }
    
    [tableViewObj reloadData];
}

-(IBAction)btnInfoClick:(id)sender
{
    [self.navigationController pushViewController:infoViewObj animated:YES];
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
